import React from 'react';
import '../../../styles/components/admin/StoreSettingsDrawerComponents/storeTimings.css';

const StoreTimings = () => {
  return <div className='storeTimings'>StoreTimings</div>;
};

export default StoreTimings;
