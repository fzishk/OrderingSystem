import React from 'react';
import '../../styles/screens/admin/whyUs.css';

import AdminHeader from '../../components/admin/AdminHeader';

const whyUsScreen = () => {
  return (
    <>
      <AdminHeader />
      <div className='whyUsScreen container-85'>whyUsScreen</div>
    </>
  );
};

export default whyUsScreen;
